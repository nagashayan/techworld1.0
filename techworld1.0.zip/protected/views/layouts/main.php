
	<?php echo $content; ?>
